from setuptools import setup, find_packages

setup(
    name='package_for_files_different_formats',
    version='0.1',
    packages=find_packages(),
    description='a package for working with files of different formats',
    author='Udodov Konstantin',
    author_email='k.udodov@bk.ru',
)
